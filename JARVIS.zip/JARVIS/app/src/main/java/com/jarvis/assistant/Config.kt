package com.jarvis.assistant

/**
 * ============  JARVIS CONFIGURATION  ============
 *
 * 1. Paste your API key into API_KEY below.
 * 2. Pick the PROVIDER that matches your key.
 * 3. Make sure API_URL and MODEL match that provider.
 *
 * With an empty API_KEY, JARVIS still runs but only answers a few
 * built-in questions (time, date, hello).
 *
 * WARNING: keys stored inside an app can be extracted from the APK.
 * That is fine for personal use. Do not publish an APK containing your key.
 */
enum class Provider { OPENAI_COMPATIBLE, ANTHROPIC }

object Config {

    // Paste your key between the quotes, e.g. "sk-...."
    val API_KEY: String = ""

    // OPENAI_COMPATIBLE works with OpenAI, OpenRouter, Groq, Together, local servers, etc.
    // ANTHROPIC works with the Claude API.
    val PROVIDER: Provider = Provider.OPENAI_COMPATIBLE

    // --- OpenAI-compatible example ---
    val API_URL: String = "https://api.openai.com/v1/chat/completions"
    val MODEL: String = "gpt-4o-mini"

    // --- Anthropic (Claude) example: switch PROVIDER above, then use ---
    // val API_URL = "https://api.anthropic.com/v1/messages"
    // val MODEL   = "claude-sonnet-5-5"

    // How JARVIS behaves. Keep answers short because they are read aloud.
    val SYSTEM_PROMPT: String =
        "You are JARVIS, a calm, witty, highly capable voice assistant. " +
            "Answer in one to three short sentences, in plain text with no markdown, " +
            "because your reply will be spoken aloud."
}
