# JARVIS – Android voice assistant

Kotlin, no external libraries beyond AndroidX. Debug APK installs on Android 7.0+ (tested target: Android 12+).

## Pinned versions
- Gradle 8.7 (via the included wrapper)
- Android Gradle Plugin 8.5.2, Kotlin 1.9.24
- compileSdk 34, targetSdk 34, minSdk 24
- JDK 17 required

## Add your API key
Edit `app/src/main/java/com/jarvis/assistant/Config.kt` and paste the key into `API_KEY`
(also choose `PROVIDER`, `API_URL`, `MODEL`). Do this BEFORE building.
Without a key JARVIS only answers time, date and hello.

## Build online (any CI / cloud build service)
Build command:  `chmod +x gradlew && ./gradlew assembleDebug`
Output APK:     `app/build/outputs/apk/debug/app-debug.apk`
Needs: JDK 17 and Android SDK Platform 34 + Build-Tools 34 (the SDK licenses accepted).

### GitHub Actions (included)
1. Create a GitHub repo and upload everything in this folder (keep the `.github` folder).
   Uploading with git or GitHub Desktop is best; the web uploader can skip hidden folders.
2. Open the repo's **Actions** tab > **Build JARVIS debug APK** > **Run workflow**.
3. When it finishes, download the **JARVIS-debug-apk** artifact (a zip containing app-debug.apk).

## Install
Copy `app-debug.apk` to the phone, open it, and allow "install unknown apps" when asked.
On first tap of the orb, allow the microphone permission.

## Local build (optional)
Open the folder in Android Studio, or run `./gradlew assembleDebug` with ANDROID_HOME set.
