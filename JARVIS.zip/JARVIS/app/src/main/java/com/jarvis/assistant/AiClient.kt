package com.jarvis.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Tiny AI client built only on Android's own HttpURLConnection + org.json,
 * so no extra libraries are needed. Keeps a short conversation history.
 */
class AiClient {

    private val executor = Executors.newSingleThreadExecutor()

    // (role, text) pairs, always kept as user/assistant pairs
    private val history = mutableListOf<Pair<String, String>>()

    /** Runs on a background thread. [onReply] is called on that background thread too. */
    fun ask(userText: String, onReply: (String) -> Unit) {
        executor.execute {
            val reply = try {
                if (Config.API_KEY.isBlank()) offlineReply(userText) else askApi(userText)
            } catch (e: Exception) {
                "I couldn't reach my servers. ${e.message ?: ""}".trim()
            }
            onReply(reply)
        }
    }

    private fun askApi(userText: String): String {
        history.add("user" to userText)
        try {
            val reply = when (Config.PROVIDER) {
                Provider.OPENAI_COMPATIBLE -> callOpenAiCompatible()
                Provider.ANTHROPIC -> callAnthropic()
            }
            history.add("assistant" to reply)
            while (history.size > 12) {
                history.removeAt(0)
                history.removeAt(0)
            }
            return reply
        } catch (e: Exception) {
            history.removeAt(history.lastIndex) // drop the unanswered user message
            throw e
        }
    }

    private fun callOpenAiCompatible(): String {
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", Config.SYSTEM_PROMPT))
        for ((role, text) in history) {
            messages.put(JSONObject().put("role", role).put("content", text))
        }
        val body = JSONObject()
            .put("model", Config.MODEL)
            .put("messages", messages)

        val response = post(body, mapOf("Authorization" to "Bearer ${Config.API_KEY}"))
        return JSONObject(response)
            .getJSONArray("choices")
            .getJSONObject(0)
            .getJSONObject("message")
            .getString("content")
            .trim()
    }

    private fun callAnthropic(): String {
        val messages = JSONArray()
        for ((role, text) in history) {
            messages.put(JSONObject().put("role", role).put("content", text))
        }
        val body = JSONObject()
            .put("model", Config.MODEL)
            .put("max_tokens", 512)
            .put("system", Config.SYSTEM_PROMPT)
            .put("messages", messages)

        val response = post(
            body,
            mapOf(
                "x-api-key" to Config.API_KEY,
                "anthropic-version" to "2023-06-01"
            )
        )
        val content = JSONObject(response).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val block = content.getJSONObject(i)
            if (block.optString("type") == "text") sb.append(block.optString("text"))
        }
        return sb.toString().trim()
    }

    private fun post(body: JSONObject, headers: Map<String, String>): String {
        val conn = URL(Config.API_URL).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 45_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            for ((k, v) in headers) conn.setRequestProperty(k, v)

            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

            if (code !in 200..299) {
                val detail = try {
                    JSONObject(text).optJSONObject("error")?.optString("message") ?: text
                } catch (e: Exception) {
                    text
                }
                throw IOException("API error $code: ${detail.take(160)}")
            }
            return text
        } finally {
            conn.disconnect()
        }
    }

    /** Used when no API key has been added yet. */
    private fun offlineReply(text: String): String {
        val t = text.lowercase(Locale.getDefault())
        return when {
            "time" in t ->
                "It is ${SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())}."
            "date" in t || "day is it" in t ->
                "Today is ${SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date())}."
            t.startsWith("hello") || t.startsWith("hey") || t.startsWith("hi ") || t == "hi" ->
                "Hello. All systems are online."
            else ->
                "My AI link is offline. Open Config.kt, add your API key, and rebuild. Then ask me anything."
        }
    }
}
