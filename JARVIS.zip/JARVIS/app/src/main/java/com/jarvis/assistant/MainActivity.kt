package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var orb: JarvisOrbView
    private lateinit var statusText: TextView
    private lateinit var userText: TextView
    private lateinit var jarvisText: TextView
    private lateinit var scroll: ScrollView

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val ai = AiClient()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                startListening()
            } else {
                setStatus("MICROPHONE PERMISSION DENIED")
                jarvisText.text = "I need microphone access to hear you. Allow it in Settings."
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        orb = findViewById(R.id.orb)
        statusText = findViewById(R.id.statusText)
        userText = findViewById(R.id.userText)
        jarvisText = findViewById(R.id.jarvisText)
        scroll = findViewById(R.id.scroll)

        tts = TextToSpeech(this, this)

        orb.setOnClickListener { onOrbTapped() }

        jarvisText.text = greeting()
        goIdle()
    }

    // ---------- Text-to-speech ----------

    override fun onInit(status: Int) {
        val engine = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            setStatus("TEXT-TO-SPEECH UNAVAILABLE")
            return
        }
        val result = engine.setLanguage(Locale.getDefault())
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale.US)
        }
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                runOnUiThread {
                    orb.state = JarvisOrbView.State.SPEAKING
                    setStatus("SPEAKING")
                }
            }

            override fun onDone(utteranceId: String?) {
                runOnUiThread { goIdle() }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                runOnUiThread { goIdle() }
            }
        })
        ttsReady = true
    }

    private fun speak(text: String) {
        val engine = tts
        if (!ttsReady || engine == null) {
            goIdle()
            return
        }
        val clean = text.replace("*", "").replace("#", "").replace("`", "").take(3900)
        engine.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "jarvis-reply")
    }

    // ---------- Button logic ----------

    private fun onOrbTapped() {
        when (orb.state) {
            JarvisOrbView.State.SPEAKING -> {
                tts?.stop()
                goIdle()
            }
            JarvisOrbView.State.LISTENING -> recognizer?.stopListening()
            JarvisOrbView.State.THINKING -> Unit // busy, ignore taps
            JarvisOrbView.State.IDLE -> {
                val hasPermission = ContextCompat.checkSelfPermission(
                    this, Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                if (hasPermission) {
                    startListening()
                } else {
                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
        }
    }

    // ---------- Speech recognition ----------

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus("SPEECH RECOGNITION UNAVAILABLE")
            jarvisText.text =
                "This device has no speech recognition service. Install or enable the Google app."
            return
        }
        tts?.stop()

        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(recognitionListener)
            }
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        userText.text = ""
        orb.state = JarvisOrbView.State.LISTENING
        setStatus("LISTENING…")
        recognizer?.startListening(intent)
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onRmsChanged(rmsdB: Float) {
            orb.setSoundLevel(rmsdB)
        }

        override fun onEndOfSpeech() {
            orb.resetSoundLevel()
            setStatus("PROCESSING…")
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (!partial.isNullOrBlank()) userText.text = partial
        }

        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (text.isNullOrBlank()) {
                goIdle()
            } else {
                handleUserSpeech(text)
            }
        }

        override fun onError(error: Int) {
            val message = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    "I didn't catch that. Tap the core and try again."
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                    "Speech recognition needs an internet connection."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    "Microphone permission is required."
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                    "The recognizer is busy. Try again in a moment."
                else -> "Speech error ($error). Tap the core to retry."
            }
            jarvisText.text = message
            goIdle()
        }
    }

    // ---------- AI round trip ----------

    private fun handleUserSpeech(text: String) {
        userText.text = text
        orb.state = JarvisOrbView.State.THINKING
        orb.resetSoundLevel()
        setStatus("THINKING…")

        ai.ask(text) { reply ->
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                showReply(reply)
            }
        }
    }

    private fun showReply(reply: String) {
        jarvisText.text = reply
        jarvisText.alpha = 0f
        jarvisText.animate().alpha(1f).setDuration(400).start()
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        speak(reply)
    }

    // ---------- Helpers ----------

    private fun goIdle() {
        orb.state = JarvisOrbView.State.IDLE
        orb.resetSoundLevel()
        setStatus("STANDING BY")
    }

    private fun setStatus(text: String) {
        statusText.text = text
    }

    private fun greeting(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val part = when {
            hour < 12 -> "Good morning"
            hour < 18 -> "Good afternoon"
            else -> "Good evening"
        }
        return "$part. All systems online. Tap the core and speak."
    }

    override fun onStop() {
        super.onStop()
        recognizer?.cancel()
        tts?.stop()
        if (orb.state != JarvisOrbView.State.THINKING) goIdle()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }
}
