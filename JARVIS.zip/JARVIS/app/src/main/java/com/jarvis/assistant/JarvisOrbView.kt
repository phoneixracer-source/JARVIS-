package com.jarvis.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.appcompat.content.res.AppCompatResources
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/**
 * The big glowing JARVIS core / microphone button.
 * Everything is drawn with Canvas, so there are no image assets or libraries.
 */
class JarvisOrbView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    var state: State = State.IDLE

    private val dp = resources.displayMetrics.density

    private var angle = 0f      // rotation of rings (degrees)
    private var phase = 0f      // 0..1, loops every 6 seconds
    private var level = 0f      // smoothed microphone loudness 0..1
    private var targetLevel = 0f

    private val deep = Color.parseColor("#06214A")

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val coreEdgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(6 * dp, 10 * dp), 0f)
    }
    private val thinPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    private val rect = RectF()
    private val micIcon = AppCompatResources.getDrawable(context, R.drawable.ic_mic)?.mutate()

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 6000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedFraction
            val speed = when (state) {
                State.IDLE -> 0.4f
                State.LISTENING -> 1.2f
                State.THINKING -> 3.5f
                State.SPEAKING -> 1.8f
            }
            angle = (angle + speed) % 360f
            level += (targetLevel - level) * 0.2f
            invalidate()
        }
    }

    /** Feed this from SpeechRecognizer.onRmsChanged (roughly -2..10). */
    fun setSoundLevel(rms: Float) {
        targetLevel = ((rms + 2f) / 12f).coerceIn(0f, 1f)
    }

    fun resetSoundLevel() {
        targetLevel = 0f
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val cx = w / 2f
        val cy = h / 2f
        val base = min(w, h) / 2f
        glowPaint.shader = RadialGradient(
            cx, cy, base,
            intArrayOf(Color.argb(150, 0, 212, 255), Color.argb(50, 30, 144, 255), Color.argb(0, 0, 80, 255)),
            floatArrayOf(0.3f, 0.65f, 1f),
            Shader.TileMode.CLAMP
        )
        val r0 = base * 0.42f
        corePaint.shader = RadialGradient(
            cx, cy, r0,
            intArrayOf(Color.rgb(24, 100, 190), deep, Color.rgb(3, 12, 30)),
            floatArrayOf(0f, 0.7f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) / 2f
        val twoPi = (2 * PI).toFloat()
        val breathe = 0.5f + 0.5f * sin(twoPi * phase * 3f) // 2-second pulse

        val accent = when (state) {
            State.IDLE -> Color.parseColor("#1E90FF")
            State.LISTENING -> Color.parseColor("#00F0FF")
            State.THINKING -> Color.parseColor("#6C9BFF")
            State.SPEAKING -> Color.parseColor("#00D4FF")
        }

        // 1. soft outer glow
        canvas.save()
        val gs = 1f + 0.05f * breathe + 0.15f * level
        canvas.scale(gs, gs, cx, cy)
        canvas.drawCircle(cx, cy, base, glowPaint)
        canvas.restore()

        // 2. tick-mark ring
        tickPaint.color = accent
        tickPaint.alpha = 130
        tickPaint.strokeWidth = 1.5f * dp
        canvas.save()
        canvas.rotate(-angle * 0.5f, cx, cy)
        for (i in 0 until 72) {
            val long = i % 6 == 0
            val inner = base * (if (long) 0.84f else 0.87f)
            canvas.drawLine(cx, cy - base * 0.91f, cx, cy - inner, tickPaint)
            canvas.rotate(5f, cx, cy)
        }
        canvas.restore()

        // 3. three bright rotating arcs
        arcPaint.color = accent
        arcPaint.strokeWidth = 3.5f * dp
        val r1 = base * 0.78f
        rect.set(cx - r1, cy - r1, cx + r1, cy + r1)
        for (k in 0 until 3) {
            canvas.drawArc(rect, angle + k * 120f, 70f, false, arcPaint)
        }

        // 4. dashed ring turning the other way
        dashPaint.color = accent
        dashPaint.alpha = 170
        dashPaint.strokeWidth = 2f * dp
        canvas.save()
        canvas.rotate(-angle * 1.5f, cx, cy)
        canvas.drawCircle(cx, cy, base * 0.68f, dashPaint)
        canvas.restore()

        // 5. thin inner ring
        thinPaint.color = accent
        thinPaint.alpha = 90
        thinPaint.strokeWidth = 1.2f * dp
        canvas.drawCircle(cx, cy, base * 0.58f, thinPaint)

        val r0 = base * 0.42f

        // 6. ripples while listening / speaking
        if (state == State.LISTENING || state == State.SPEAKING) {
            ripplePaint.color = accent
            ripplePaint.strokeWidth = 2f * dp
            val frac = (phase * 3f) % 1f
            ripplePaint.alpha = (170 * (1f - frac)).toInt()
            canvas.drawCircle(cx, cy, r0 * (1.1f + frac * 0.55f), ripplePaint)
            ripplePaint.alpha = (90 + 140 * level).toInt().coerceAtMost(230)
            canvas.drawCircle(cx, cy, r0 * (1.12f + level * 0.45f), ripplePaint)
        }

        // 7. the core
        val cs = (1f + 0.04f * breathe + 0.1f * level)
        canvas.save()
        canvas.scale(cs, cs, cx, cy)
        canvas.drawCircle(cx, cy, r0, corePaint)
        coreEdgePaint.color = accent
        coreEdgePaint.strokeWidth = 3f * dp
        canvas.drawCircle(cx, cy, r0, coreEdgePaint)
        canvas.restore()

        // 8. microphone icon
        micIcon?.let {
            val half = (r0 * 0.45f).toInt()
            it.setBounds(cx.toInt() - half, cy.toInt() - half, cx.toInt() + half, cy.toInt() + half)
            it.setTint(accent)
            it.draw(canvas)
        }
    }
}
